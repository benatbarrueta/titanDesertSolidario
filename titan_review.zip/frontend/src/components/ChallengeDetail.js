import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import '../styles/ChallengeDetail.css';
import { apiClient } from '../apiClient';

const ChallengeDetail = () => {
  const { id } = useParams();
  const [challenge, setChallenge] = useState(null);
  const [warriors, setWarriors] = useState([]);
  const [selectedWarriors, setSelectedWarriors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);

  useEffect(() => {
    window.scrollTo(0, 0);
    setLoading(true);
    Promise.all([apiClient.getChallengeById(id), apiClient.getWarriors()])
      .then(([challengeData, warriorsData]) => {
        setChallenge(challengeData);
        setWarriors(warriorsData);
        setLoading(false);
      })
      .catch(err => {
        setError(err.message);
        setLoading(false);
      });
  }, [id]);

  const handleSelectWarrior = (warriorId) => {
    if (selectedWarriors.includes(warriorId)) {
      setSelectedWarriors(selectedWarriors.filter(id => id !== warriorId));
    } else if (selectedWarriors.length < challenge.options[0].numberOfSelections) {
      setSelectedWarriors([...selectedWarriors, warriorId]);
    }
  };

  const handleSubmit = () => {
    setSubmitting(true);
    setError(null);
    setSuccessMessage(null);

    const participationData = {
      challengeId: challenge.id,
      selectedWarriors,
    };

    apiClient.createParticipation(participationData)
      .then(() => {
        setSuccessMessage('¡Participación registrada con éxito!');
        setSelectedWarriors([]);
      })
      .catch(err => {
        setError(err.message);
      })
      .finally(() => {
        setSubmitting(false);
      });
  };

  if (loading) return <p>Cargando...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div className="challenge-detail">
      <h1 className="challenge-title">{challenge.title}</h1>
      <p className="challenge-description">{challenge.description}</p>

      <div className="warrior-selection">
        <h2>Selecciona tus guerreros:</h2>
        <div className="warrior-grid">
          {warriors.map(warrior => (
            <div
              key={warrior.id}
              className={`warrior-card ${selectedWarriors.includes(warrior.id) ? 'selected' : ''}`}
              onClick={() => handleSelectWarrior(warrior.id)}
            >
              <p>{warrior.name}</p>
            </div>
          ))}
        </div>
      </div>

      <button onClick={handleSubmit} disabled={submitting || selectedWarriors.length !== challenge.options[0].numberOfSelections}>
        {submitting ? 'Enviando...' : 'Participar'}
      </button>

      {successMessage && <p className="success-message">{successMessage}</p>}
      {error && <p className="error-message">{error}</p>}
    </div>
  );
};

export default ChallengeDetail;
